package com.infor.ca.wmb.convert;

public class ConversionExample {
    public static void testMain(String[] args) {
        // Original ESQL
        String esqlCode = """
            CREATE COMPUTE MODULE ProcessCustomer
                CREATE FUNCTION Main() RETURNS BOOLEAN
                BEGIN
                    SET OutputRoot.SOAP.Body.Customer.ID = InputRoot.SOAP.Body.Customer.ID;
                    SET OutputRoot.SOAP.Body.Customer.Age = CAST(InputRoot.SOAP.Body.Customer.Age AS INTEGER);
                    RETURN TRUE;
                END;
            END MODULE;
            """;

        // Convert to Spring Boot
        String springBootCode = MigrationHelper.generateSpringBootCode(esqlCode);
        System.out.println(springBootCode);
    }
}