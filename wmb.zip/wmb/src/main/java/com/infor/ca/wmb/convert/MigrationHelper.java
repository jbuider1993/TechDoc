package com.infor.ca.wmb.convert;

public class MigrationHelper {
    public static String generateSpringBootCode(String esqlCode) {
        StringBuilder javaCode = new StringBuilder();

        // Parse ESQL module
        if (esqlCode.contains("CREATE COMPUTE MODULE")) {
            javaCode.append("@Service\n");
            javaCode.append("public class ")
                    .append(extractModuleName(esqlCode))
                    .append(" {\n");

            // Convert Main() function
            javaCode.append("    public void processMessage(Message input, Message output) {\n");

            // Convert SET statements
            for (String line : esqlCode.split("\n")) {
                if (line.trim().startsWith("SET")) {
                    ESQLParser.ESQLStatement stmt = ESQLParser.parseSetStatement(line);
                    javaCode.append("        ")
                            .append(convertToJavaSetter(stmt))
                            .append(";\n");
                }
            }

            javaCode.append("    }\n");
            javaCode.append("}");
        }

        return javaCode.toString();
    }
}