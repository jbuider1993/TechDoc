package com.infor.ca.wmb.convert;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProcessCustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public CustomerResponse processCustomer(CustomerRequest request) {
        CustomerResponse response = new CustomerResponse();

        // Converted from ESQL SET statements
        response.setCustomerId(request.getCustomerId());
        response.setAge(Integer.valueOf(request.getAge()));

        // Additional Spring Boot specific processing
        customerRepository.save(convertToEntity(response));

        return response;
    }

    private CustomerEntity convertToEntity(CustomerResponse response) {
        CustomerEntity entity = new CustomerEntity();
        BeanUtils.copyProperties(response, entity);
        return entity;
    }
}