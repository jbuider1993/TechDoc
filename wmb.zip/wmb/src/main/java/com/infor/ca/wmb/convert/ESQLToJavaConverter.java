package com.infor.ca.wmb.convert;

public class ESQLToJavaConverter {
    public static String convertPath(String esqlPath) {
        // Convert ESQL path to Java getter/setter chain
        // Example: "InputRoot.SOAP.Body.Customer.Name" -> "getInputRoot().getSOAP().getBody().getCustomer().getName()"
        String[] parts = esqlPath.split("\\.");
        StringBuilder javaPath = new StringBuilder();

        for (String part : parts) {
            javaPath.append("get")
                    .append(Character.toUpperCase(part.charAt(0)))
                    .append(part.substring(1))
                    .append("().");
        }

        return javaPath.substring(0, javaPath.length() - 1);
    }

    public static String convertCast(String esqlCast) {
        // Convert ESQL CAST to Java casting
        if (esqlCast.contains("CAST") && esqlCast.contains("AS")) {
            String value = esqlCast.substring(esqlCast.indexOf("(") + 1, esqlCast.indexOf("AS")).trim();
            String type = esqlCast.substring(esqlCast.indexOf("AS") + 2, esqlCast.indexOf(")")).trim();

            switch (type.toUpperCase()) {
                case "INTEGER": return "Integer.valueOf(" + value + ")";
                case "DECIMAL": return "new BigDecimal(" + value + ")";
                case "DATE": return "LocalDate.parse(" + value + ")";
                default: return value;
            }
        }
        return esqlCast;
    }
}