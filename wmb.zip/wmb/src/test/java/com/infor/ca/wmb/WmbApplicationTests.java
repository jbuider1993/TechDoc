package com.infor.ca.wmb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WmbApplicationTests {

	@Test
	void contextLoads() {
	}

}
