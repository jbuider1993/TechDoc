docker-compose -f docker-compose.yml up -d


docker login --username jbuilder1993 --password Infor1234567890

docker tag oauth-service:5.0 jbuilder1993/oauth-service:5.0
docker push jbuilder1993/oauth-service:5.0
docker tag employee-service:5.0 jbuilder1993/employee-service:5.0
docker push jbuilder1993/employee-service:5.0
