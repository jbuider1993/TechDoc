url: http://localhost:8181/cxf/service/rest/healthcheck/validstatus/{container}
post:
request body

 [
        {
            "context": "cmeljaonLoadContext",
            "route": "camelJosnlodingRote1",
            "status": "stopped"
        },
        {
            "context": "cmeljaonLoadContext",
            "route": "camelJosnlodingRote2",
            "status": "stopped"
        }
    ]