package com.av.ca.esb.healthcheck.common;

public class constant {
    public static final String command= "/app/%s/fabric8-karaf-1.2.0.redhat-630329/bin/client -u devuser -p av123 camel:route-list "; 
    //public static final String localCommand = "C:/workspace/ABC/fuse/jboss-fuse-6.3.0.redhat-329/bin/client -u admin -p admin camel:route-list ";
    public static final String host = "10.172.113.118";
    public static final int port = 22;
    public static final String userName = "t2273326";
    public static final String password = "Jan2021";
}
