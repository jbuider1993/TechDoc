package com.av.ca.healthcheck.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ContextRouteStatus {
	@JsonProperty("context")
	private String context;
	@JsonProperty("route")
	private String route;
	@JsonProperty("status")
	private String status;
	
	@JsonCreator()
	public ContextRouteStatus(@JsonProperty("context") String context, @JsonProperty("route") String route, @JsonProperty("status") String status) {
		this.context = context;
		this.route = route;
		this.status = status;
	}
	
	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
