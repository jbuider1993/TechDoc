package com.av.ca.healthcheck.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;

public class RouteStatusResponse {

	private String status;
	 @JsonInclude(JsonInclude.Include.NON_NULL)
	private List<ValidatedRouteStatus> validatedStatus;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ValidatedRouteStatus> getValidatedStatus() {
		return validatedStatus;
	}

	public void setValidatedStatus(List<ValidatedRouteStatus> validatedStatus) {
		this.validatedStatus = validatedStatus;
	}



}
