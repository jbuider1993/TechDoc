package com.av.ca.healthcheck;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.camel.Exchange;
import org.apache.camel.Route;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.av.ca.esb.healthcheck.common.constant;
import com.av.ca.healthcheck.model.ContextRouteStatus;
import com.av.ca.healthcheck.model.RouteStatusResponse;
import com.av.ca.healthcheck.model.ValidatedRouteStatus;

public class ApiHealthCheckProcessor implements Processor {
	private final static Logger LOGGER = LoggerFactory.getLogger(ApiHealthCheckProcessor.class);

    public void routeValidstatusProcess(Exchange exchange) throws Exception {
		List<ContextRouteStatus> reqRouteStatusList = new ArrayList<>();
		reqRouteStatusList = exchange.getIn().getBody(List.class);
        
		String contextName = exchange.getContext().getName();
    	List<Route> routeList = exchange.getContext().getRoutes();
    	ProducerTemplate template = exchange.getContext().createProducerTemplate();
    	String status = "";
    	String routeId = "";
    	List<ContextRouteStatus> routeStatusList = new ArrayList<>();
        for ( Route rte : routeList ) {
        	routeId = rte.getId();
        	status = template.requestBody("controlbus:route?routeId=" + routeId + "&action=status", null, String.class);
        	ContextRouteStatus routeStatus = new ContextRouteStatus(contextName, routeId, status);
        	routeStatusList.add(routeStatus);
        	LOGGER.info("Controlbus Route Status: " + status + " for route: " + routeId);
        }
		
		RouteStatusResponse routeStatusResponse = validtionStatus(reqRouteStatusList, routeStatusList);
		exchange.getOut().setBody(routeStatusResponse);
    }
	
    public void validstatusProcess(Exchange exchange) throws Exception {
        
		List<ContextRouteStatus> reqRouteStatusList = new ArrayList<>();
		String container = exchange.getIn().getHeader("container", String.class);
		reqRouteStatusList = exchange.getIn().getBody(List.class);
		
		String command = String.format(constant.command, container);
		List<ContextRouteStatus> routeStatusList = localCommand(command);
		RouteStatusResponse routeStatusResponse = validtionStatus(reqRouteStatusList, routeStatusList);
		exchange.getOut().setBody(routeStatusResponse);
    }
    
    private RouteStatusResponse validtionStatus(List<ContextRouteStatus> reqRouteStatusList, List<ContextRouteStatus> routeStatusList) {
        String context;
        String route;
        String status;
        String validation = "failed";
        int successNum = 0;
        List<ValidatedRouteStatus> validStatusList = new ArrayList<>();
        
        if (Objects.nonNull(reqRouteStatusList) && !reqRouteStatusList.isEmpty()) {
	        for (ContextRouteStatus reqRouteStatus : reqRouteStatusList) {
	        	context = reqRouteStatus.getContext();
	        	route = reqRouteStatus.getRoute();
	        	status = reqRouteStatus.getStatus();
	        	for (ContextRouteStatus routeStatus : routeStatusList) {
	        	   	if (context.equalsIgnoreCase(routeStatus.getContext())  && route.equalsIgnoreCase(routeStatus.getRoute())) {
	    	   			validation = "success";
	        	   		if (!status.equalsIgnoreCase(routeStatus.getStatus())) {
	            	   		validation = "failed";
	        	   		} else {
	        	   			successNum++;	
	        	   		}
	        	   		ValidatedRouteStatus validatedRouteStatus = new ValidatedRouteStatus( context,  route,  status,  validation);
	        	   		validStatusList.add(validatedRouteStatus);
	        	   	}
	        	}
	    	}
        }
        	
    	RouteStatusResponse routeStatusResponse = new RouteStatusResponse();
    	
    	if (successNum != reqRouteStatusList.size()) {
    		routeStatusResponse.setStatus("failed");
        	routeStatusResponse.setValidatedStatus(validStatusList);
    	} else {
    		routeStatusResponse.setStatus("success");
    	}
    	return routeStatusResponse;  	
    }
    
	@Override
	public void process(Exchange exchange) throws Exception {
		Map<String, String> routeStatuMap = new HashMap<>();
		String searchRoute = exchange.getIn().getHeader("route", String.class);
		
		//routeStatuMap = rmoteFabricCommand(host, userName, password, command);
		String routeName;
		String routeStatus;
		
		routeStatuMap.put("sendGeneralRequestToMQ", "Started");
		routeStatuMap.put("apiStatusRoute", "Started");
		
		/*
		if (Objects.nonNull(searchRoute)) {
			routeStatus = routeStatuMap.get(searchRoute);
			exchange.getOut().setBody(routeStatus);
		} else {
			exchange.getOut().setBody(routeStatuMap);			
		}
		*/
		exchange.getOut().setBody(routeStatuMap);			
	}
	
	private static List<ContextRouteStatus> localCommand(String command) {
		List<ContextRouteStatus> routeStatuList = new ArrayList<>();
		
		/*
		ContextRouteStatus routeStatus = new ContextRouteStatus("cmeljaonLoadContext", "camelJosnlodingRote1", "stopped");
		routeStatuList.add(routeStatus);
		routeStatus = new ContextRouteStatus("cmeljaonLoadContext", "camelJosnlodingRote2", "Started");
		routeStatuList.add(routeStatus);
		*/
		
		try {
            Process processor = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(processor.getInputStream()));
            
            try {
            	processor.waitFor();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
            
		    String readStr;
		    String[] sections;
        	//System.out.println(" Rout   Status");
            while ( Objects.nonNull(readStr = reader.readLine())) {
            	sections = readStr.split(" +");
            //	System.out.println(String.format(" %s   %s", sections[1], sections[2]));
            	ContextRouteStatus contextRouteStatus = new ContextRouteStatus(sections[0], sections[1], sections[2]);
            	routeStatuList.add(contextRouteStatus);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
		return routeStatuList;
	}
	
	
	private static Map<String, String> rmoteFabricCommand(String host, String userName, String password, String command) {
		//UserInfo userInfo = new sshRemoteUserInfo(userName, password);
		//Session session = null;
		//Channel channel = null;
		Map<String, String> retResult = new HashMap<>();
		
		/*
		try {
			session = jsch.getSession(userName, host, constant.port);
		    session.setUserInfo(userInfo);
		    session.connect();
		    
		    channel=session.openChannel("exec");
		    ((ChannelExec)channel).setCommand(command);
		    channel.setInputStream(null);
		    ((ChannelExec)channel).setErrStream(System.err);
		 
            BufferedReader reader = new BufferedReader(new InputStreamReader(channel.getInputStream()));
		 
		    channel.connect();
		    
		    String readStr;
		    String[] sections;
            while ( Objects.nonNull(readStr = reader.readLine())) {
            	sections = readStr.split(" +");
            	retResult.put(sections[1], sections[2]);
            }
		    

		} catch (Exception e) {
			System.out.println(" Exception occuerd while call SSH to server");
		} finally {
		   channel.disconnect();
		   session.disconnect();
		}
		*/
		return retResult;
	}

	
	public static void main(String args[]) {
	    rmoteFabricCommand(constant.host, constant.userName, constant.password, constant.command);
	}
  }