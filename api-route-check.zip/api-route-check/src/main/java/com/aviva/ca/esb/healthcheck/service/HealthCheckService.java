package com.av.ca.esb.healthcheck.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.camel.Body;

import com.av.ca.healthcheck.model.ContextRouteStatus;

public class HealthCheckService {
	
	@POST
	@Path("/validstatus/{container}") 
	@Consumes(MediaType.APPLICATION_JSON)  
	@Produces(MediaType.APPLICATION_JSON)	
	public Response validstatus(@PathParam("container") String container, @Body List<ContextRouteStatus> routeStatuList) {
		return Response.ok().build();
	}
	

	@POST
	@Path("/routestatus") 
	@Consumes(MediaType.APPLICATION_JSON)  
	@Produces(MediaType.APPLICATION_JSON)	
	public Response routeValidstatus(@Body List<ContextRouteStatus> routeStatuList) {
		return Response.ok().build();
	}
	
	
	
	
}
