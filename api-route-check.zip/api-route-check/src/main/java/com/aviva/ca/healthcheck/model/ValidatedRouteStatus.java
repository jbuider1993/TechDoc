package com.av.ca.healthcheck.model;

public class ValidatedRouteStatus {
	private String context;
	private String route;
	private String status;
	private String validation;

	
	public ValidatedRouteStatus(String context, String route, String status, String validation) {
		super();
		this.context = context;
		this.route = route;
		this.status = status;
		this.validation = validation;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getValidation() {
		return validation;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}

}
